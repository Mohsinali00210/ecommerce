# Shan Zee UI v2 — one brand colour (#198754), custom alerts, guidance

1. Copy `static/css/*` and `static/js/*` into your project's `static/` (new file: `static/js/szui.js`; changed: `css/modern.css`, `js/app.js`).
2. Replace your `templates/` folder with the one here.
3. Run `collectstatic` if you use it, then hard-refresh (Ctrl+F5).

## What changed
- **Colour**: every accent, gradient, badge, promo and button now uses #198754 (with its own tints/shades). Red/amber are kept only for errors/warnings.
- **Alerts**: no more browser `alert()` / `confirm()`. Use
  `SZ.toast("Saved", "success")`, `await SZ.confirm("Delete?", {tone:"danger"})`, `SZ.alert("…")`.
  Any stray `alert()` call is automatically shown as a styled toast.
  Declarative: `<form data-sz-confirm="Are you sure?">` or on any button/link.
- **Guidance**: `<aside class="sz-guide" data-guide="unique-id">` panels (collapsible, remembered per visitor) on cart, checkout, addresses, wallet, withdraw, orders, order detail, profile, edit profile, wishlist, contact, product and tracking pages. Inline "?" help: `<i class="bi bi-question-lg sz-help" title="…"></i>`.
- Page titles and buttons now carry icons (Bootstrap Icons).
