# Shan Zee UI v2 — one brand colour (#198754), custom alerts, guidance, dark/light toggle

1. Copy `static/css/*` and `static/js/*` into your project's `static/` (new: `js/szui.js`; changed: `css/modern.css`, `js/app.js`).
2. Replace your `templates/` folder with the one here.
3. Run `collectstatic` if you use it, then hard-refresh (Ctrl+F5).

## Theme toggle
- Sun/moon switch in the header (`base2.html`, class `theme-toggle`). Choice is saved in localStorage (`shanzee-theme`);
  with no saved choice it follows the visitor's system setting. A tiny script in `<head>` applies it before first paint (no flash).
- Dark styles live at the end of `static/css/modern.css` (section 14). Colours are tokens (`--mz-surface`, `--mz-ink`, …) so new pages inherit them.
- Pages with their own hard-coded inline colours may need small tweaks — use the tokens instead of `#fff`.

## Alerts
`SZ.toast("Saved", "success")`, `await SZ.confirm("Delete?", {tone:"danger"})`, `SZ.alert("…")`. Stray `alert()` calls become toasts.
Declarative: `<form data-sz-confirm="Are you sure?">`.

## Guidance
`<aside class="sz-guide" data-guide="unique-id">` panels (collapsible, remembered) on the key pages.
